#!/bin/bash


sudo apt update
sudo apt install -y --no-install-recommends gvfs gvfs-backends
sudo apt install -y --no-install-recommends \
    xorg openbox obconf lxpanel lxappearance pcmanfm \
    lxsession-logout dunst diodon picom pnmixer dbus-x11 ibus mlterm
sudo apt install -y --no-install-recommends pulseaudio pavucontrol udiskie

sudo apt install -y --no-install-recommends git
mkdir -p ~/.icons ~/.themes
rm -rf ~/.icons/Windows-XP ~/.themes/Windows-XP-Embedded
git clone --depth 1 https://github.com/B00merang-Artwork/Windows-XP.git ~/.icons/Windows-XP
TMP="$(mktemp -d)"
git clone --depth 1 https://github.com/B00merang-Project/Windows-XP.git "$TMP/gtk"
cp -r "$TMP/gtk/Windows XP Embedded" ~/.themes/Windows-XP-Embedded
rm -rf "$TMP"
mkdir -p ~/.mlterm
mkdir -p ~/.config/openbox
mkdir -p ~/.config/pcmanfm
mkdir -p ~/.config/pcmanfm/default
cp -f install_files/main ~/.mlterm/main
cp -f install_files/autostart ~/.config/openbox/autostart
cp -f install_files/wallpaper.jpg ~/.config/pcmanfm/default/wallpaper.jpg
cp -f install_files/desktop-items-0.conf ~/.config/pcmanfm/default/desktop-items-0.conf

touch ~/.config/openbox/.first_run

echo "exec openbox-session" > ~/.xinitrc
